var completion_block = {
      type: 'html-keyboard-response',
      stimulus: '<div>Your completion code is TEEN'+
      '<br><br><br>' + 
        'Send your code to smtashji@caltech.edu to let us know you finished the study. We will send your payment via paypal. Thank you!' +
        '</div>',
    	choices: jsPsych.NO_KEYS
};

