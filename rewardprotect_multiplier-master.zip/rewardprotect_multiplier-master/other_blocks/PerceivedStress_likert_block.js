var prompt2 = {
	type: 'html-keyboard-response',
	stimulus:'<p> For the following questions, indicate <b> how often </b> you felt or thought a certain way <b> during the last month </b>.</p>' +
		'<p> Press space to start </p>',
    choices:['space'], 
};

var scale_1 = [
	"Never",
	"Almost Never",
	"Sometimes",
	"Fairly Often",
	"Very Often"
];

var PerceivedStress = {
	type: 'survey-likert',
	questions:[
		{prompt: '<p style="text-align:center; font-size:32px"><b>In the last month...</b>'+
	'<p style="text-align:center; font-size:24px">How often have you been upset because of something that happened unexpectedly?',
	name: 'Stress1',
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt that  you were unable to control the important things in your life?',
	name: 'Stress2', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt nervous and "stressed"?',
	name: 'Stress3', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt confident about your ability to handle your personal problems?',
	name: 'Stress4', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt that things were going your way?',
	name: 'Stress5', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you found that you could not cope with all the things that you had to do?',
	name: 'Stress6', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you been able to control irritations in your life?',
	name: 'Stress7', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt that you were on top of things?',
	name: 'Stress8', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you been angered because of things that were outside of your control?',
	name: 'Stress9', 
	labels: scale_1},
	
	{prompt: '<p style="text-align:center; font-size:24px">How often have you felt difficulties were piling up so high that you could not overcome them?',
	name: 'Stress10', 
	labels: scale_1}
	
	],
	randomize_question_order:false
};

var PerceivedStress_block = {
	timeline: [prompt2, PerceivedStress],
	randomize_order: false,
};

