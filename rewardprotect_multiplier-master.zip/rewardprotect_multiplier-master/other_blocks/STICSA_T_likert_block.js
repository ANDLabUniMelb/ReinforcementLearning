var prompt = {
	type: 'html-keyboard-response',
	stimulus:'<p>Please indicate for each statement how often <b> in general </b> the statement is true for you. </p>' +
		'<p> Press the space bar to start </p>',
    choices:['space'], 
};

var scale = [
	"Not at all",
	"A little",
	"Moderately",
	"Very much"
];

var STICSAt = {
	type: 'survey-likert',
	questions:[
		{prompt: '<p style="text-align:center; font-size:32px"><b>Generally...</b>'+
		'<p style="text-align:center; font-size:24px">My heart beats fast',
		name: 'STICSAT1', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My muscles are tense',
		name: 'STICSAT2', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel agonized over my  problems',
		name: 'STICSAT3', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I think that others won\'t approve of me',
		name: 'STICSAT4', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel like I\'m missing out on things because I can\'t make up my mind soon enough',
		name: 'STICSAT5', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel dizzy',
		name: 'STICSAT6', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">My muscles feel weak',
		name: 'STICSAT7', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I feel trembly and shaky',
		name: 'STICSAT8', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I picture some future misfortune',
		name: 'STICSAT9', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I can\'t get some thoughts out of my mind',
		name: 'STICSAT10', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I have trouble remembering things',
		name: 'STICSAT11', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My face feels hot',
		name: 'STICSAT12', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I think that the worst will happen',
		name: 'STICSAT13', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My arms and legs feel stiff',
		name: 'STICSAT14', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My throat feels dry',
		name: 'STICSAT15', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I keep busy to avoid uncomfortable thoughts',
		name: 'STICSAT16', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I cannot concentrate without irrelevant thoughts intruding',
		name: 'STICSAT17', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My breathing is fast and shallow',
		name: 'STICSAT18', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I worry that I cannot control my thoughts as well as I would like to',
		name: 'STICSAT19', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I have butterflies in my stomach',
		name: 'STICSAT20', 
		labels: scale},
		
		{prompt: '<p style="text-align:center; font-size:24px">My palms feel clammy',
		name: 'STICSAT21', 
		labels: scale}
		
	],
	randomize_question_order:false
};

var STICSAt_block = {
	timeline: [prompt, STICSAt],
	randomize_order: false,
};

