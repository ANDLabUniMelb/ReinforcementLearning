var welcome_block_rwd = {
    type: 'html-keyboard-response',
    stimulus: '<p>Welcome to the experiment!</p>'+ 
    '<p> You will play two games and answer a few questions.</p>'+
    '<p>Press the space bar to begin reading the instructions for the first game.</p>',
    choices: ['space']
};
