//anxiety control questionnaire http://people.bu.edu/tabrown/Manuscripts/Brown%20White%20et%20al%202004.pdf
//https://www.sciencedirect.com/science/article/pii/S0005791601000349

var prompt3 = {
	type: 'html-keyboard-response',
	stimulus:'<p>Please indicate for each statement how much you think each statement is typical of you. </p>' +
		'<p> Press the space bar to start </p>',
    choices:['space'], 
};

var scale_2 = [
	"Strongly Disagree",
	"Moderately Disagree",
	"Slightly Disagree",
	"Slightly Agree",
	"Moderately Agree",
	"Strongly Agree"
];

var ACQscale = {
	type: 'survey-likert',
	questions:[
		{prompt: '<p style="text-align:center; font-size:24px">I am usually able to avoid threat quite easily.',
		name: 'ACQ1', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">How well I cope with difficult situations depends on whether I have outside help.',
		name: 'ACQ2', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">When I am put under stress, I am likely to lose control.',
		name: 'ACQ3', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I can usually stop my anxiety from showing.',
		name: 'ACQ4', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">When I am frightened by something, there is generally nothing I can do.',
		name: 'ACQ5', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">My emotions seem to have a life of their own.',
		name: 'ACQ6', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">There is little I can do to influence people\'s judgments of me.',
		name: 'ACQ7', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">Whether I can successfully escape a frightening situation is always a matter of chance with me.',
		name: 'ACQ8', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I often shake uncontrollably.',
		name: 'ACQ9', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I can usually put worrisome thoughts out of my mind easily.',
		name: 'ACQ10', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">When I am in a stressful situation, I am able to stop myself from breathing too hard.',
		name: 'ACQ11', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I can usually influence the degree to which a situation is potentially threatening to me.',
		name: 'ACQ12', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I am able to control my level of anxiety.',
		name: 'ACQ13', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">There is little I can do to change frightening events.',
		name: 'ACQ14', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">The extent to which a difficult situation resolves itself has nothing to do with my actions.',
		name: 'ACQ15', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">If something is going to hurt me, it will happen no matter what I do.',
		name: 'ACQ16', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I can usually relax when I want.',
		name: 'ACQ17', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">When I am under stress, I am not always sure how I will react.',
		name: 'ACQ18', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I can usually make sure people like me if I work at it.',
		name: 'ACQ19', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">Most events that make me anxious are outside my control.',
		name: 'ACQ20', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I always know exactly how I will react to difficult situations.',
		name: 'ACQ21', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I am unconcerned if I become anxious in a difficult situation, because I am confident in my ability to cope with my symptoms.',
		name: 'ACQ22', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">What people think of me is largely outside of my control.',
		name: 'ACQ23', 
		labels: scale_2},
	
		{prompt: '<p style="text-align:center; font-size:24px">I usually find it hard to deal with difficult problems.',
		name: 'ACQ24', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">When I hear someone has a serious illness, I worry that I am next.',
		name: 'ACQ25', 
		labels: scale_2},
		
		{prompt: '<p style="text-align:center; font-size:24px">When I am anxious, I find it hard to focus on anything other than my anxiety.',
		name: 'ACQ26', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I am able to cope as effectively with unexpected anxiety as I am with anxiety that I expect to occur.',
		name: 'ACQ27', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I sometimes think, "Why even bother to try coping with my anxiety when nothing I do seems to affect how frequently or intensely I experience it?"',
		name: 'ACQ28', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I often have the ability to get along with "difficult" people.',
		name: 'ACQ29', 
		labels: scale_2},

		{prompt: '<p style="text-align:center; font-size:24px">I will avoid conflict due to my inability to successfully resolve it.',
		name: 'ACQ30', 
		labels: scale_2}
		
	],
	randomize_question_order:false
};

var ACQ_block = {
	timeline: [prompt3, ACQscale],
	randomize_order: false,
};

