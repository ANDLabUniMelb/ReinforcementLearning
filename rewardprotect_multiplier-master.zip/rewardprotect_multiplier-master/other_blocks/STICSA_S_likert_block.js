var prompt = {
	type: 'html-keyboard-response',
	stimulus:'<p>Please indicate for each statement the degree to which each statement is descriptive of your mood <b> at this  moment </b>. </p>' +
		'<p> Press the space bar to start </p>',
    choices:['space'], 
};

var scale = [
	"Not at all",
	"A little",
	"Moderately",
	"Very much"
];

var STICSAs = {
	type: 'survey-likert',
	questions:[
		{prompt: '<p style="text-align:center; font-size:32px"><b>At this moment...</b>'+
		'<p style="text-align:center; font-size:24px">My heart beats fast',
		name: 'STICSAS1', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My muscles are tense',
		name: 'STICSAS2', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel agonized over my  problems',
		name: 'STICSAS3', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I think that others won\'t approve of me',
		name: 'STICSAS4', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel like I\'m missing out on things because I can\'t make up my mind soon enough',
		name: 'STICSAS5', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I feel dizzy',
		name: 'STICSAS6', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">My muscles feel weak',
		name: 'STICSAS7', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I feel trembly and shaky',
		name: 'STICSAS8', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I picture some future misfortune',
		name: 'STICSAS9', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I can\'t get some thoughts out of my mind',
		name: 'STICSAS10', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I have trouble remembering things',
		name: 'STICSAS11', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My face feels hot',
		name: 'STICSAS12', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I think that the worst will happen',
		name: 'STICSAS13', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My arms and legs feel stiff',
		name: 'STICSAS14', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My throat feels dry',
		name: 'STICSAS15', 
		labels: scale},

		{prompt: '<p style="text-align:center; font-size:24px">I keep busy to avoid uncomfortable thoughts',
		name: 'STICSAS16', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I cannot concentrate without irrelevant thoughts intruding',
		name: 'STICSAS17', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">My breathing is fast and shallow',
		name: 'STICSAS18', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I worry that I cannot control my thoughts as well as I would like to',
		name: 'STICSAS19', 
		labels: scale},
	
		{prompt: '<p style="text-align:center; font-size:24px">I have butterflies in my stomach',
		name: 'STICSAS20', 
		labels: scale},
		
		{prompt: '<p style="text-align:center; font-size:24px">My palms feel clammy',
		name: 'STICSAS21', 
		labels: scale},
		
		{prompt: '<p style="text-align:center; font-size:24px">I am answering this survey carefully',
		name: 'STICSAS22', 
		labels: scale}
		
	],
	randomize_question_order:false
};

var STICSAs_block = {
	timeline: [prompt, STICSAs],
	randomize_order: false,
};

