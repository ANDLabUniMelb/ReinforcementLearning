# RewardProtect_Multiplier

stakes 1 and 5, multiplier outcomes 0-45