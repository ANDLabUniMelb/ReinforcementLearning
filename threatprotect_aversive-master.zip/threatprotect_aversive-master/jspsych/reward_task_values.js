rwd_n_trials = 225;


var rwd_images = ['img/fairy_1.png', 'img/fairy_2.png', 'img/fairy_3.png', 'img/fairy_4.png',
			'img/elf_blue.png', 'img/elf_orange.png', 'img/elf_yellow.png', 'img/elf_purple.png',
			'img/house_3.png', 'img/house_4.png', 'img/house_2.png', 'img/house_6.png',
			'img/house_1.png', 'img/house_5.png', 'img/flames.png', 'img/flames_0.png', 'img/flames_1.png',
			'img/flames_2.png', 'img/flames_3.png', 'img/flames_4.png', 'img/flames_5.png',
			'img/flames_6.png', 'img/flames_7.png', 'img/flames_8.png', 'img/flames_9.png', 'img/flame_0.png', 
			'img/flame_1.png', 'img/flame_2.png', 'img/flame_3.png', 'img/flame_4.png', 'img/flame_5.png', 'img/flame_6.png', 
			'img/flame_7.png', 'img/flame_8.png', 'img/flame_9.png','img/flame_10.png', 'img/flame_11.png', 'img/flame_12.png', 
			'img/flame_13.png','img/flame_14.png', 'img/flame_15.png', 'img/flame_16.png', 'img/flame_17.png', 'img/flame_18.png', 'img/flame_19.png'];

var rwd_stakes_1 = 'img/dragon_stakes1.png';
var rwd_stakes_1 = 'img/dragon_stakes1.png';
var rwd_stakes_4 = 'img/dragon_stakes5.png';
var rwd_stakes_4 = 'img/dragon_stakes5.png';

var rwd_low_stakes = {
    stakes_a: rwd_stakes_1,
    stakes_b: rwd_stakes_1
};

var rwd_high_stakes = {
    stakes_a: rwd_stakes_4,
    stakes_b: rwd_stakes_4
};

var rwd_stakes_1_num = 'img/dragon_stakes1_num.png';
var rwd_stakes_1_num = 'img/dragon_stakes1_num.png';
var rwd_stakes_4_num = 'img/dragon_stakes5_num.png';
var rwd_stakes_4_num = 'img/dragon_stakes5_num.png';

var rwd_low_stakes_num = {
    stakes_a: rwd_stakes_1_num,
    stakes_b: rwd_stakes_1_num
};

var rwd_high_stakes_num = {
    stakes_a: rwd_stakes_4_num,
    stakes_b: rwd_stakes_4_num
};

rwd_stakes_types = [
    {stakes: rwd_stakes_1_num, ...rwd_low_stakes_num},
    {stakes: rwd_stakes_1_num, ...rwd_low_stakes_num},
    {stakes: rwd_stakes_4_num, ...rwd_high_stakes_num},
    {stakes: rwd_stakes_4_num, ...rwd_high_stakes_num},
];

var rwd_result_1 = 'img/elf_blue.png';
var rwd_result_2 = 'img/elf_orange.png';
var rwd_result_3 = 'img/elf_yellow.png';
var rwd_result_4 = 'img/elf_purple.png';


var rwd_choice_11 = {
    name: 'img/house_3.png',  // shown with rwd_choice_12
    result: rwd_result_1
}
var rwd_choice_21 = {
    name: 'img/house_4.png',  // shown with rwd_choice_22
    result: rwd_result_1
}
var rwd_choice_12 = {
    name: 'img/house_2.png',  // shown with rwd_choice_11
    result: rwd_result_2
}
var rwd_choice_22 = {
    name: 'img/house_6.png',  // shown with rwd_choice_21
    result: rwd_result_2
}

var rwd_choice_8 = {
	name: 'img/house_1.png',
	result: rwd_result_3
}

var rwd_choice_9 = {
	name: 'img/house_5.png',
	result: rwd_result_4
}

var rwd_choice_5 = {
	name: 'img/elf_yellow.png',
	result: rwd_result_3
}
var rwd_choice_6 = {
	name: 'img/elf_purple.png',
	result: rwd_result_4
}

var rwd_get_result = function(choice) {
    if (choice == rwd_choice_11.name) return rwd_choice_11.result;
    else if (choice == rwd_choice_21.name) return rwd_choice_21.result;
    else if (choice == rwd_choice_12.name) return rwd_choice_12.result;
    else if (choice == rwd_choice_22.name) return rwd_choice_22.result;
    else if (choice == rwd_choice_8.name)  return rwd_choice_8.result;
    else if (choice == rwd_choice_9.name)  return rwd_choice_9.result;
    else if (choice == rwd_choice_5.name)  return rwd_choice_5.result;
    else if (choice == rwd_choice_6.name)  return rwd_choice_6.result;
}

var rwd_choices_types = [
    {choice_a: rwd_choice_11, choice_b: rwd_choice_12, type: '1'},
    {choice_a: rwd_choice_12, choice_b: rwd_choice_11, type: '1\''},
    {choice_a: rwd_choice_21, choice_b: rwd_choice_22, type: '2'},
    {choice_a: rwd_choice_22, choice_b: rwd_choice_21, type: '2\''},
];


var rwd_test_types = [
	{choice_a: rwd_choice_8, choice_b: rwd_choice_9, type:'3'},
	{choice_a: rwd_choice_5, choice_b: rwd_choice_6, type:'4'},
];


var rwd_resource_img = 'img/flames.png';
var rwd_resource_imgs = ['img/flames_9.png', 'img/flames_8.png', 'img/flames_7.png', 'img/flames_6.png',
'img/flames_5.png', 'img/flames_4.png', 'img/flames_3.png', 'img/flames_2.png', 'img/flames_1.png', 'img/flames_0.png'];

//var rwd_lost_imgs = ['img/coin_0.png', 'img/coin_1.png', 'img/coin_2.png', 'img/coin_3.png',
//'img/coin_4.png', 'img/coin_5.png', 'img/coin_6.png', 'img/coin_7.png', 'img/coin_8.png', 'img/coin_9.png',
//'img/coin_10.png', 'img/coin_11.png', 'img/coin_12.png', 'img/coin_13.png',
//'img/coin_14.png', 'img/coin_15.png', 'img/coin_16.png', 'img/coin_17.png', 'img/coin_18.png', 'img/coin_19.png'];

var rwd_lost_imgs = ['img/flame_9.png', 'img/flame_8.png', 'img/flame_7.png', 'img/flame_6.png',
'img/flame_5.png', 'img/flame_4.png', 'img/flame_3.png', 'img/flame_2.png', 'img/flame_1.png', 'img/flame_0.png',
'img/flame_19.png', 'img/flame_18.png', 'img/flame_17.png', 'img/flame_16.png',
'img/flame_15.png', 'img/flame_14.png', 'img/flame_13.png', 'img/flame_12.png', 'img/flame_11.png', 'img/flame_10.png'];


//var rwd_resource_imgs = [null];
//for ( i=1; i <= 9; i++) {
//    rwd_resource_imgs.push('img/sack_' + i + '.png');
//};

rwd_wording = 'Attacked by';
rwd_wordings = 'Your outcome';
