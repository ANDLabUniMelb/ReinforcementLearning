var completion_block = {
      type: 'html-keyboard-response',
      stimulus: '<div>Your completion code is 36E15226'+
      '<br><br><br>' + 
        'Click <a href="https://app.prolific.ac/submissions/complete?cc=36E15226">here</a> to log your completion' +
        '</div>',
    	choices: jsPsych.NO_KEYS
};

