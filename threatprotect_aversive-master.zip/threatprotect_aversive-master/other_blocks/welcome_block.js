var welcome_block = {
    type: 'html-keyboard-response',
    stimulus: '<p>Now you will play the second game!</p><p>Press the space bar to ' +
        'begin reading the instructions for the second game.</p>',
    choices: ['space']
};
